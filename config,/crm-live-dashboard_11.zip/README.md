# Painel CRM — Resumo com filtro PV / Supervisor / Consultor (atualização de hora em hora)

Painel ao vivo, conectado à API JSON-RPC do CRM (Odoo) em `global.solucoes.plus`,
usando a metodologia oficial de classificação definida pela Isabela (etapas →
atendido/convertido/concluído/em trâmite, e produto+solicitação → categorias de
receita). Atualiza os dados a cada 1 hora por padrão.

## Modo TV (`/tv`)

Além do painel principal (`/`), existe uma tela separada em **`/tv`**, pensada para
ficar rodando sozinha numa TV/monitor: mostra **um consultor por vez**, com
Meta x Realizado (indicador principal, receita total), metas por produto
(Renovação, Aparelhos, Banda Larga), % do mailing/leads do mês já atendidos,
funil de vendas (Proposta enviada / Aceite enviado / Proposta recusada /
Finalizado) e um ranking dos 3 consultores com maior % de meta batida — e
avança automaticamente para o próximo consultor a cada 12s (configurável via
`TV_SLIDE_SECONDS`). Não inclui Ligações nem WhatsApp (sem esses dados no CRM).
Desde 2026-09-16, o modo TV mostra **só os consultores/supervisores do PV
02** (pedido da Isabela) — pra mudar o PV ou tirar o filtro, é só editar a
constante `TV_PV_FILTRO` no início do `<script>` de `templates/tv.html`
(o painel principal `/` continua mostrando todos os PVs normalmente).

## Consulta interativa (`/explorar`)

Desde 2026-09-16, além do `/tv` (rotação automática, só PV 02), existe
**`/explorar`**: a mesma lógica e o mesmo cartão do modo TV (Meta x Realizado,
metas por produto, atendimentos, funil, ranking Top 3 e foto), mas com
**seleção manual em cascata** — três combos no topo da página: **PV →
Supervisor → Consultor**. Não avança sozinho de tela em tela; quem está
olhando escolhe o que quer ver, mas os números continuam se atualizando
sozinhos (mesmo `/api/data`, mesmo intervalo de `REFRESH_SECONDS`).

- Ao escolher só o PV, mostra a **visão geral do PV** (soma de todas as
  equipes/consultores daquele PV) — ranking Top 3 nesse caso é entre os PVs.
- Ao escolher PV + Supervisor (sem consultor), mostra a **visão geral daquele
  supervisor/equipe** — ranking Top 3 entre os supervisores do mesmo PV.
- Ao escolher PV + Supervisor + Consultor, mostra o consultor individual,
  igual ao modo TV — ranking Top 3 entre os consultores da mesma equipe.
- Mostra todos os PVs (não tem o filtro `TV_PV_FILTRO` do `/tv`).
- Foto: mesma lógica do `/tv` (casa pelo primeiro nome via `fotos.py`); no
  nível "visão geral do PV" não tem foto (não é uma pessoa), só o rótulo "PV".

As metas vêm de **`config/metas.xlsx`** (abas `EQUIPES` e `USUARIOS`, com as
colunas `RECEITA_TOTAL`, `QUANTIDADE_BL`, `RECEITA_RENOVACAO`,
`RECEITA_APARELHOS`), pré-preenchido com os valores que a Isabela mandou por
print em 2026-09-15. A meta de cada equipe é a meta do supervisor daquela
equipe; a meta de cada PV é a soma das metas das equipes/supervisores daquele
PV. Um consultor sem linha em `USUARIOS` aparece como "Sem meta" em vez de
0%. Para atualizar as metas, é só editar esse Excel (mesmo nome/abas/colunas)
e reiniciar o serviço.

**Resolvido em 2026-09-16**: o 4º produto do esboço ("Móvel") não é uma
categoria de receita nova — é a própria **Receita Total** (a Isabela já
passa ali todo o valor considerado). "Metas por produto" no modo TV agora
mostra 4 caixinhas: Receita Total, Renovação, Aparelhos e Banda Larga (grid
2x2).

**Pendências conhecidas** (avisar a Isabela): o funil de vendas mostra
apenas contagem de CNPJs/leads por etapa, sem os valores em R$ mostrados no
esboço (o esboço tinha "R$ 1,85M" etc. por etapa — dá pra adicionar usando
`expected_revenue` do lead, mas ainda não foi confirmado se é esse o campo
certo, nem se é valor esperado ou já vendido); o "velocímetro" do esboço foi
simplificado para uma barra horizontal com as mesmas 3 faixas de cor
(vermelho/amarelo/verde), em vez do arco/ponteiro literal.

O tempo de troca de slide no modo TV é de **no mínimo 1 minuto** (confirmado
com a Isabela em 2026-09-15) — `TV_SLIDE_SECONDS` pode aumentar esse valor,
mas o código nunca deixa cair abaixo de 60s.

## Receita sempre do mês atual + pedidos "puxados" para o mês atual

A partir de 2026-09-15 (pedido da Isabela): **a receita (tiles do topo, metas
e o Meta x Realizado do modo TV) é sempre calculada com o período "Mês
atual"**, mesmo que o filtro de Período no topo do painel principal esteja em
"Últimos 60 dias" — esse seletor continua afetando leads, atendimento,
funil, produção e movimentações, só não afeta mais a receita.

Além disso, alguns pedidos (`sale.order`, identificados pelo número/cotação,
ex: `S41934`) foram criados/fechados no mês anterior mas **têm que contar
como receita do mês atual mesmo assim** (pedido da Isabela em 2026-09-15 —
antes a v6 tinha feito o oposto, excluído esses pedidos, o que estava
errado). A Isabela manda a lista desses números e eles entram na receita do
mês atual mesmo com a `create_date` da linha sendo de antes do início do
mês. Essa lista fica em **`config/pedidos_mes_atual.txt`** (um código por
linha, sem aspas). Para incluir mais pedidos: adicionar o(s) número(s)
nesse arquivo (uma linha por código) e reiniciar o serviço. O painel mostra
quantos pedidos foram incluídos assim como nota ao lado do filtro
PV/Supervisor/Consultor. Essa lista só afeta o período "Mês atual" (não o
"Últimos 60 dias").

Nota: 3 dos números da lista (`40541577`, `49980193`, `49984693`) não têm o
formato do número de pedido do CRM (que começa com "S", ex: `S41934`) — a
Isabela confirmou que é pra desconsiderar (não fazem mal, só não vão casar
com nenhum pedido).

## O que o painel mostra

- **Filtro de período**: Mês atual (coorte por data de criação) ou Últimos 60 dias
  (janela móvel, sempre "hoje - 60 dias" até agora), com um seletor no topo do painel.
- **Filtro PV / Supervisor / Consultor** (3 caixas de seleção em cascata, no topo):
  ao escolher um PV, o seletor de Supervisor mostra só os supervisores daquele PV; ao
  escolher um Supervisor, o de Consultor mostra só os consultores daquele supervisor.
  Com "Todos" em todos os filtros, os cards mostram o total geral.
- **Os mesmos indicadores em qualquer nível do filtro** (Todos, PV, Supervisor ou
  Consultor específico): Leads totais, Atendido, Convertido, Movimentações de etapa,
  Funil (Proposta enviada x Aceite enviado), Produção (Concluído x Em trâmite) e
  Receita (Total, Renovação, Qtd. banda larga, Aparelho) — sempre recalculados para o
  escopo e período selecionados.
- **Ranking por equipe**: total de leads, atendidos e convertidos por equipe (sempre
  para o período selecionado, independente do filtro de PV/Supervisor/Consultor).
- **Ranking por consultor**: quantidade de movimentações de etapa no escopo selecionado
  (exclui contas técnicas/sistema, configurável via `SYSTEM_USER_IDS`, e exclui etapas
  que não contam como movimentação — ver `NON_MOVEMENT_STAGES` abaixo). Se um PV ou
  Supervisor estiver selecionado, a lista mostra só os consultores daquele escopo.

A hierarquia PV → Supervisor → Consultor vem de `config/hierarquia_usuarios.xlsx`
(ver `hierarchy.py`). Leads/linhas/movimentações de usuários fora dessa hierarquia
(equipes não mapeadas, como BKO/GERENTE VIVO/PV071-00001/2/3, ou sem consultor
identificado) entram no total "Todos", mas não aparecem ao filtrar por um PV
específico — a contagem desses casos aparece como nota ao lado dos filtros.

## Metodologia (arquivos em `config/`)

- `config/etapas_estagio.xlsx`: classifica cada etapa do CRM em ATENDIDO / CONVERTIDO
  / CONCLUIDO / EM TRAMITE (SIM/NÃO). Um lead é contado numa dessas categorias pela
  sua **etapa atual**.
- `config/classificacao_receita.xlsx` (abas SOLICITACAO e PRODUTOS): define, para 4
  categorias de receita (RECEITA TOTAL, RENOVAÇÃO, BANDA LARGA, APARELHO), quais tipos
  de solicitação e quais categorias de produto contam. **Uma linha de pedido só entra
  numa categoria se os dois critérios baterem (E lógico)**, confirmado com a Isabela.
  A receita é atribuída ao PV/Supervisor/Consultor pelo campo `salesman_id` da linha
  de pedido (vendedor da linha).
  **Importante (confirmado com a Isabela em 2026-09-16): as 4 categorias são
  independentes, RECEITA TOTAL não é a soma das outras 3** — em particular,
  solicitações do tipo RENOVAÇÃO/MIGRAÇÃO/MIGRAÇÃO UP/MIGRAÇÃO DOWN e as
  categorias de produto de Aparelho **propositalmente não contam** como
  RECEITA TOTAL (só contam nas suas categorias específicas). Por isso é
  normal um consultor ter, por exemplo, mais Renovação do que Receita Total —
  não é bug.
  **Além disso (confirmado com a Isabela em 2026-09-16): só conta como
  receita um pedido cujo lead/oportunidade de origem esteja atualmente na
  etapa CONCLUIDO ou EM TRAMITE** (mesmas flags de `config/etapas_estagio.xlsx`
  usadas em Produção). Um pedido cujo lead esteja em qualquer outra etapa
  (ex: Proposta enviada, Aceite enviado, etc.) ou sem lead vinculado **não
  entra em nenhuma categoria de receita**. Essa ligação é feita via
  `sale.order.line → order_id (sale.order) → opportunity_id (crm.lead) →
  stage_id`. Se o campo `opportunity_id` não existir nesse CRM (customização
  específica), o log do serviço registra o erro e a receita fica zerada
  naquele ciclo até ajustar o nome do campo em `app.py`.
  **Correção em 2026-09-16**: os tipos de solicitação aceitos para BANDA
  LARGA estavam errados — a lista correta (confirmada pela Isabela) é
  **ALTA, PORTABILIDADE, PORTABILIDADE PF, MIGRACAO DE TECNOLOGIA**
  (substituindo NOVO/PORTADO/PORTADO PF/MIGRAÇÃO DE TECNOLOGIA, que eram os
  nomes usados nas outras categorias, não os da Banda Larga). O critério de
  produto (`All / Fixa Básica - Dados` / `All / Fixa Básica PF - Dados`)
  não mudou.
- `config/hierarquia_usuarios.xlsx` (export res.users: Login, Nome, Equipes de vendas):
  usado para montar o filtro PV → Supervisor → Consultor (ver `hierarchy.py`). Regras:
  - PV = parte antes do "-" no nome da equipe (ex: "PV 02 - Equipe Alexandre" → "PV 02").
  - Supervisor = o membro do time cujo primeiro nome bate com o sufixo da equipe (ex:
    "Alexandre Ornellas" é o supervisor de "PV 02 - Equipe Alexandre"). Quando o sufixo
    não bate com ninguém (ex: "Equipe Carteira"), o time fica sem supervisor identificado.
  - Equipes fora do padrão "PV - Equipe <Nome>" (BKO, GERENTE VIVO, PV071-00001/2/3) são
    **excluídas** deste filtro — aparecem apenas no "Ranking por equipe" normal, e a
    contagem de leads fora do escopo é mostrada como nota ao lado dos filtros.

- **Etapas que não contam como "movimentação"** (confirmado com a Isabela em
  2026-09-15, em `classification.py` → `NON_MOVEMENT_STAGES`): quando um lead
  entra numa dessas etapas, a mudança é ignorada na contagem de movimentações
  por consultor, mesmo aparecendo em `mail.tracking.value`:
  - AGUARDANDO INTERAÇÃO
  - TENTATIVA DE CONTATO
  - CLIENTE JA RENOVADO
  - CORRECAO CONSULTOR
  - ATUALIZACOES POR ROBO

  Qualquer outra etapa (ex: PRIMEIRO CONTATO COM O CLIENTE, NAO TEM INTERESSE,
  ATENDIMENTO AGENDADO, PROPOSTA ENVIADA, PROPOSTA RECUSADA, ACEITE ENVIADO,
  SUPER VISÃO, QUALITY CALL PENDENTE, INPUT REALIZADO, etc.) conta normalmente.
  Se essa lista mudar, é só editar o `NON_MOVEMENT_STAGES` em `classification.py`.

Se a classificação de etapas, de receita ou a hierarquia de usuários mudar, basta
substituir os arquivos correspondentes em `config/` (mesmo nome, mesmas abas/colunas)
e reiniciar o serviço — não precisa mexer no código.

## Como funciona (técnico)

- `odoo_client.py`: cliente JSON-RPC (autentica com `common.authenticate` e chama
  `execute_kw`/`search_read`/`read_group`).
- `classification.py`: carrega os dois arquivos de classificação de `config/` e expõe
  funções de classificação de etapa/receita, além de `is_movement_stage()` (etapas
  que não contam como movimentação — lista hardcoded `NON_MOVEMENT_STAGES`).
- `hierarchy.py`: carrega `config/hierarquia_usuarios.xlsx`, deriva PV/Supervisor por
  equipe e casa cada login com o `id` numérico do usuário no CRM (`res.users`).
- `app.py`: a cada `REFRESH_SECONDS` (padrão 3600 = 1h), calcula os dados para os
  **dois períodos** (mês atual e últimos 60 dias) de uma vez, e para cada período monta
  tanto o total geral ("root") quanto a árvore completa PV → Supervisor → Consultor —
  tudo já pré-calculado e guardado em memória. O endpoint `/api/data` serve esse cache
  inteiro; o filtro de período/PV/Supervisor/Consultor no front-end só troca qual pedaço
  do JSON já recebido é exibido — não faz nenhuma chamada nova ao CRM, então trocar o
  filtro é instantâneo entre uma atualização e outra.
- **Nota técnica**: `read_group` do Odoo nesse servidor sub-conta registros de
  `crm.lead` (provavelmente por causa de um módulo de controle de acesso
  customizado, `_plus_access`) — por isso o painel busca os leads do período
  individualmente (poucos campos, leve) e agrega em Python, em vez de usar
  `read_group` para esse modelo. Pelo mesmo motivo (precisar atribuir cada
  linha/movimentação a um PV/Supervisor/Consultor e, no caso das movimentações,
  filtrar pela etapa de destino), `sale.order.line` e `mail.tracking.value` também são
  buscados como registros individuais e agregados em Python.

## Rodar localmente

```bash
pip install -r requirements.txt
export CRM_LOGIN=bi@global
export CRM_PASSWORD=sua_senha
python3 app.py
# abra http://localhost:8080
```

## Deploy no Railway

1. Suba esta pasta (incluindo `config/`) para um repositório no GitHub (o `.env`
   já está no `.gitignore`).
2. No Railway: **New Project → Deploy from GitHub repo**.
3. Em **Variables**, adicione:
   - `CRM_HOST` = `https://global.solucoes.plus/jsonrpc`
   - `CRM_DB` = `global`
   - `CRM_LOGIN` = `bi@global`
   - `CRM_PASSWORD` = (a senha)
   - `REFRESH_SECONDS` = `3600`
   - `SYSTEM_USER_IDS` = `1`
   - `LAST_N_DAYS` = `60` (opcional — período alternativo do seletor; padrão já é 60)
4. O Railway detecta o `Procfile` e usa `gunicorn` automaticamente.
5. Abra a URL gerada — é essa URL que fica aberta na TV/monitor.

## Auditoria detalhada (linha a linha)

Duas rotas de diagnóstico, sem autenticação (a URL do Railway não é
divulgada, mas não coloque nada além dos próprios dados do CRM nelas):

- **`/api/export_linhas_mes`**: todas as linhas de pedido do mês atual
  (mesmo critério usado no cálculo de receita), uma por produto vendido, com
  cliente, número do pedido, PV/Supervisor/Consultor, categoria de produto,
  tipo de solicitação, valor, etapa do lead vinculado e se conta como
  receita. É a fonte da aba "Por Consultor - Detalhado" do Excel que a
  Isabela pede pra auditar os resultados.
- **`/api/debug_pedidos?nomes=S12345,S67890`**: mesma coisa, mas só pra uma
  lista específica de números de pedido — útil pra investigar um caso
  pontual sem baixar tudo.

## Observações e próximos ajustes possíveis

- "Assistente Plus" (uid 1) aparece com muitas movimentações — parece ser uma
  conta técnica/automação, não uma pessoa; já vem excluída do ranking por padrão
  (`SYSTEM_USER_IDS=1`), mas vale confirmar.
- A equipe "Sales" ainda concentra um volume desproporcional de leads — mesma
  observação da v1, ainda não filtrada.
- Tipos de solicitação fora das 4 listas de receita (ex: "MIGRAÇÃO PP", "TT")
  simplesmente não contam para nenhuma categoria — isso é esperado, mas vale
  revisar periodicamente se surgirem tipos novos não classificados.
- A receita é atribuída pelo vendedor da linha de pedido (`salesman_id`), que pode
  não ser sempre o mesmo consultor dono do lead (`user_id`) — vale confirmar com a
  Isabela se isso é o esperado ou se a atribuição deveria seguir o dono do lead.
